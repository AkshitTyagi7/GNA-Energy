export const ENERGY_UNIT= "MU";
export const COST_UNIT= "Rs./KWh";
export const COST_MU="Rs./MWh";
export const COST="Rs Cr"
export const MEGA_POWER_UNIT= "MW";
