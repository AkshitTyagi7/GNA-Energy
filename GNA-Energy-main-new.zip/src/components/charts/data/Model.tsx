export default interface ChartLabelValue {
  labels: string[];
  values: GLfloat[];
  backgroundColor?: string[];
}